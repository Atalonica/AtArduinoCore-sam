#include "Arduino.h"
#include "variant.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Returns a 32-bit true random number (NIST 800-22) */
uint32_t tRandom()
{
  /* ENABLE */
  TRNG->CTRLA.bit.ENABLE = 0x01;
  /* WAIT FOR DATA READY */
  while(TRNG->INTFLAG.bit.DATARDY == 0);
  /* DISABLE */
  TRNG->CTRLA.bit.ENABLE = 0x00;
  /* RETURN DATA */
  return TRNG->DATA.reg; // Also clears data ready flag
}

#ifdef __cplusplus
}
#endif
