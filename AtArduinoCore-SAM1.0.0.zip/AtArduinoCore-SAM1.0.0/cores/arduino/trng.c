#include "Arduino.h"
#include "variant.h"

#ifdef __cplusplus
extern "C"
{
#endif

  uint32_t tRandom()
  {
    /* ENABLE */
    TRNG->CTRLA.bit.ENABLE = 0x01;
    /* WAIT FOR DATA READY */
    while (TRNG->INTFLAG.bit.DATARDY == 0)
      ;
    /* DISABLE */
    TRNG->CTRLA.bit.ENABLE = 0x00;
    /* RETURN DATA */
    return TRNG->DATA.reg; // Also clears data ready flag
  }

  void tRandomBytes(uint8_t *r, uint8_t n)
  {

    uint32_t rand32 = 0;
    TRNG->CTRLA.bit.ENABLE = 0x01;

    for (uint8_t i = 0; i < n; i++)
    {
      if (i % 4 == 0)
      {
        while (TRNG->INTFLAG.bit.DATARDY == 0)
          ;
        rand32 = TRNG->DATA.reg;
      }
      r[i] = (uint8_t)((rand32 >> (24 - (i % 4) * 8)) & 0xFF);
    }

    TRNG->CTRLA.bit.ENABLE = 0x00;
  }

#ifdef __cplusplus
}
#endif
