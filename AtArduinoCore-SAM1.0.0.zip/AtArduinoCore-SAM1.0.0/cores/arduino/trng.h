
#pragma once

#include "sam.h"

#ifdef __cplusplus
extern "C" {
#endif

extern uint32_t tRandom( void ) ;

#ifdef __cplusplus
}
#endif
